%% Script to parse set of files programatically

%% Reading directory information...
% Assumes 'ArmsLegs' is a subdirectory of the working directory
fileInfo = dir(['ArmsLegs', filesep, '*.txt']);
fileList = { fileInfo.name}; % Make cell array of strings

%% Actually parsing files

for k = numel(fileList):-1:1
    disp(fileList{k})
    ArmsLegs(k).FileName = fileList{k};
    ArmsLegs(k).Data = dlmread(['ArmsLegs', filesep,fileList{k}],'\t',1,0);
end
