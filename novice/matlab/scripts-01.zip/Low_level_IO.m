%% Low level file I/O
%
% We will experiment with traditional file-handling in Matlab.

%% Opening the file
fileID = fopen('HeightWaistData.txt','r');

%% Actually reading the file
formatSpec = '%f %f';
HeightWaistData = textscan(fileID,formatSpec,...
      'Delimiter','\t','Headerlines',1);

%% Closing the file
fclose(fileID);

%% Visualise the cell array
% figure(1);
% cellplot(HeightWaistData); % Draws representation of cell array

%% Convert cell array to standard rectangular matrix 
% (tall & thin)
HWData = cell2mat(HeightWaistData);
% do some statistics...
% disp(mean(HWData))

%% Cleaning the data

Heights = HWData(:,1);
Waists = HWData(:,2);

% Find bad observations
badObs = isnan(Heights) | isnan(Waists);
% Clean actual data
cleanHeights = Heights(~badObs);
cleanWaists = Waists(~badObs);

disp(mean([ cleanHeights, cleanWaists] ));

%% Save cleaned data to a file

save('CleanHeightWaist', 'Heights', 'Waists');


